import inquirer from 'inquirer';
import { IAluno } from '../interfaces/IAluno';
import { AlunoManager } from '../managers/AlunoManager';

export async function promptParaDetalhesDoAluno(nome: String, idade: number, matricula: String): Promise<IAluno> {
    
  const p = await inquirer.prompt([
        {
            type: 'input',
            name: 'nome',
            message: 'Qual é o seu nome?',
          },
          {
            type: 'input',
            name: 'idade',
            message: 'Qual a sua idade?',
          },
          {
            type: 'input',
            name: 'matricula',
            message: 'Qual é a sua matricula?',
            validate: input => input.trim() !== '' ? true : 'A matrícula não pode ser vazia'
          },
          {
            type: 'confirm',
            name: 'confirmar',
            message: 'Tem certeza?',
            default: true,
          },

    ]);
    const res = await inquirer.prompt(p);

    return {
      nome: nome,
      idade: idade,
      matricula: matricula,  
    };
}

export async function promptMenuPrincipal(): Promise<String> {
    
  const p: IAluno = { nome: "CLarice", idade: 20, matricula: "12321072" };
  const aluno = new AlunoManager();

  aluno.adicionarAluno(p);
  aluno.listarAlunos;
    
  return `A escolha do usuário foi: ${aluno}`;
}
