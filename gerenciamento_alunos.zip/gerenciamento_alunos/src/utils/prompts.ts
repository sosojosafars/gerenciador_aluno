import inquirer from 'inquirer';
import { IAluno } from '../interfaces/IAluno';
import { AlunoManager } from '../managers/AlunoManager';

async function promptParaDetalhesDoAluno(): Promise<IAluno> {

    const p = await inquirer.prompt([
        {
            type: 'input',
            name: 'nome',
            message: 'Qual é o seu nome?',
          },
          {
            type: 'input',
            name: 'idade',
            message: 'Qual a sua idade?',
          },
          {
            type: 'input',
            name: 'matricula',
            message: 'Qual é a sua matricula?',
            validate: input => input.trim() !== '' ? true : 'A matrícula não pode ser vazia'
          },
          {
            type: 'confirm',
            name: 'confirmar',
            message: 'Tem certeza?',
            default: true,
          },

    ]);
    const res = await inquirer.prompt(p);
    
    return promptParaDetalhesDoAluno();
}


async function promptMenuPrincipal(): Promise<String> {
    
    const p: IAluno = { nome: "CLarice", idade: 20, matricula: "12321072" };
    const aluno = new AlunoManager();

    console.log("Lista inicial de produtos:");
    aluno.listarAlunos();
    aluno.adicionarAluno(p);


    return promptMenuPrincipal();
}
