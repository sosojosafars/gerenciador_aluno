import { IAluno } from "../interfaces/IAluno.js";
import { Aluno } from "../models/Aluno.js";

export class AlunoManager {
 private alunos: IAluno[] = [];


adicionarAluno(novoAluno: IAluno): void {
    const existe = this.alunos.find(p => p.matricula.toLowerCase() === novoAluno.matricula.toLowerCase());
    if (existe) {
        this.alunos.push(novoAluno);
       console.log(`Aluno '${novoAluno.nome}' adicionado com sucesso.`);
  }else{
    console.error(`"Erro: O aluno com matrícula ${novoAluno.matricula} já está
cadastrado!") `);
    return;
  }
}

buscarAlunoPorMatricula(matricula: string): IAluno | undefined {
    return this.alunos.find(p => p.matricula === matricula);
  }

listarAlunos(matricula: string): boolean  | undefined{
    const aluno = this.buscarAlunoPorMatricula(matricula);
    if (!aluno) {
      console.error("Nenhum aluno cadastrado.");
      return false;
    }
}

}

const alunos: { nome: string; idade: number; matricula: string }[] = [
    { nome: "Sofia", idade: 17, matricula: "12300012" },
    { nome: "Erica", idade: 48, matricula: "1250129" },
    { nome: "Lissandro", idade: 48, matricula: "1230121" },
    { nome: "Samuel", idade: 13, matricula: "1234208" },
  ];
  
  alunos.forEach(alunoData => {
    const aluno = new Aluno(alunoData.nome, alunoData.idade, alunoData.matricula);
    aluno.exibirDetalhes();
  });
    