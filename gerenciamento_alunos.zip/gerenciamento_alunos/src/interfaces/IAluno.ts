
 export interface IAluno {
      nome: String
      idade: number
      matricula: String    
  }
