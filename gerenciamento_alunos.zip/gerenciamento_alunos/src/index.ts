import { IAluno } from "./interfaces/IAluno";
import { AlunoManager } from "./managers/AlunoManager"
import { Aluno } from "./models/Aluno"


async function main() {
    
alunos.listarAlunos();
}