import { IAluno } from "./interfaces/IAluno";
import { AlunoManager } from "./managers/AlunoManager"
import { Aluno } from "./models/Aluno"
import { promptMenuPrincipal } from "./utils/prompts";
import { promptParaDetalhesDoAluno } from "./utils/prompts";

async function main() {
    const p1 = new AlunoManager();

    for (let i = 0; i < 5; i++) {
        promptMenuPrincipal();
      }
}